=== RetroPosts ===
Contributors: ohryan
Tags: dashboard widget, post history
Tested up to: 3.6
Stable tag: 0.1
License GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

RetroPosts creates a dashboard widget that displays past blog posts.

== Description == 

It's easy to forget about the great blog posts you've written in the past. This plugin surfaces post from the current week in your blog's history. 

Feature requests and ideas welcome: ryan@ohryan.ca

== Installation ==

1. Upload the plugin.
2. Activate it. 
3. Check your dashboard.

== Changelog ==

= 0.1 =
* Initial version. Nothing to change. 